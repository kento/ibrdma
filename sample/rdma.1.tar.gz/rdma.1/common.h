

int file_dump(char * path, char *content);
int get_pid(void);
int get_rand(void);

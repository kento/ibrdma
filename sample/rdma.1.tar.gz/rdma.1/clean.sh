#!/bin/sh

mv sierra*.core ~/Trash